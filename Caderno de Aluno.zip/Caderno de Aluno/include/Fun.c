
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#include "../Lib/lib.h"

Flashcard lista[10];
arvore T = NULL;

extern int menu, menulembrete, menuflashcard, menuquiz, media, i, numero, indice, indiceUtilitario;
char pesquisa[50];

    int op = -1;
    char texto[200] = {0};
    struct Registro *elemento;
    Lista lista2;

Materia nomeM[10];

void funcQuiz (){  //Onde o usuario informa sobre o quiz de autoavalia��o
    printf("Digite o nome da materia: ");
    scanf("%s", nomeM[numero].nome);
    getchar();

    printf("Quantas perguntas voce fez? Digite aqui: ");
    scanf("%d", &nomeM[numero].perguntas);
    getchar();

    printf("Quantas voce acertou? Digite aqui: ");
    scanf("%d", &nomeM[numero].pontuacao);
    getchar();

    media = nomeM[numero].perguntas/2;
    if (media < nomeM[numero].pontuacao)
    {
        printf("\nParabens! Acima da media na materia: %s\n", nomeM[numero].nome);
    }
    else
    {
        printf("\nVoce precisa estudar mais na materia: %s! Abaixo da media\n", nomeM[numero].nome);
    }
    insertNode(&T, nomeM[numero].nome); //Endere�o T receber� o nome de cada mat�ria adicionada
    numero++;
}

void insertNode(arvore *t, char d[20]){  //t � inserido na �rvore
    if (*t == NULL)
    {
        *t = (struct no*) malloc(sizeof(struct no));//Alocando mem�ria e verificando se tem espa�o suficiente
        if (*t != NULL)
        {
            (*t)->esq = NULL;
            (*t)->dir = NULL;
            strcpy((*t)->dado, d);
        }
        else
            printf("ERRO: Memoria insuficiente!");
    }
    else if (strcmp(d,(*t)->dado) < 0)  //Comparando os dados e informando se h� uma duplica��o ou n�o
        insertNode(&(*t)->esq, d);
    else if (strcmp(d, (*t)->dado) > 0)
        insertNode(&(*t)->dir, d);
    else
        printf("ATENCAO: Duplicacao de no!");
    return;
}

void inOrdem(arvore t){  //Fun��o para organizar e printar em ordem ALFABETICA
    if (t != NULL)
    {
        inOrdem(t->esq);
        printf("- %s\n", t->dado);
        inOrdem(t->dir);
    }
    return;
}

void insereFlash(){  //Fun��o que recebe os dados da materia a nota da mesma e logo em seguida lan�a para o sort
    printf("Digite o materia da materia: ");
    scanf("%s", &lista[indice].materia);
    getchar();

    printf("Digite a nota de %s: ", lista[indice].materia);
    scanf("%s", &lista[indice++].nota);
    getchar();
    sortFlashcard(indice);
    printf("\n=====================================================================\n\n");
}

void pesquisaMateriaFlash(){   //Fun��o para receber o nome da mat�ria que o usu�rio deseja pesquisar e que � enviado para a pesquisa binaria
    printf("Digite o nome da materia: ");
    scanf("%s", &pesquisa);
    getchar();
    indiceUtilitario = pesquisaBinaria(pesquisa, 0, indice);
    printf("Nota de %s: %s\n", pesquisa, lista[indiceUtilitario].nota);
}

void sortFlashcard(int tam){  //InsertionSort para ordena��o dos dados no flashcard e jogando para a lista e seu aux
    int k, j;
    Flashcard aux;
    for (k = 1; k <= tam - 1; k++)
    {
        aux = lista[k];
        j = k - 1;
        while (j >= 0 && strcmp(aux.materia, lista[j].materia) < 0)
        {
            lista[j+1] = lista[j];
            j--;
        }
        lista[j+1] = aux;
    }
    return;
}

int pesquisaBinaria(char dado[], int inicio, int fim){  //Fun��o que faz a busca do dado desejado pelo usu�rio que � informado no menu do flashcard
//� feito a compara��o utilizando o m�todo de pesquisa bin�ria
    int meio = (inicio + fim)/2;
    if (strcmp(lista[meio].materia, dado) == 0)
        return(meio);
    if (inicio >= fim)
        return -1;
    if (strcmp(dado, lista[meio].materia) < 0)
        pesquisaBinaria(dado, inicio, meio-1);
    else
        pesquisaBinaria(dado, meio+1, fim);
    return 0;
}

void cria(Lista *lista2){ //Cria a lista para lembretes
    lista2->inicio=NULL;
    lista2->final=NULL;
}

int insere(Lista *lista2,char *texto){ //Nesta função utilizamos o malloc para alocação dinamica, e atribuimos texto a lista de lembretes
    struct Registro *aux=(struct Registro*)malloc(sizeof(struct Registro));
    if(aux == NULL) return 0;
    strcpy(aux->texto,texto);
    aux->prox=NULL;

    if(lista2->inicio==NULL)
        lista2->inicio=lista2->final=aux;
    else
    {
        lista2->final->prox=aux;
        lista2->final=aux;
    }
    return 1;
}

void le(char *texto){ //Recebe a variável texto
printf("\nEscreva seu recadinho: ");
scanf("%[^\n]s",texto);
}

void imprime_lista(Lista*lista2){ //Imprimir lista de lembretes
struct Registro*aux = lista2->inicio;
while(aux!=NULL){
printf("\n%s\n", aux->texto);
aux=aux->prox;
}
}

void pulaLinha(){
    printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
}
