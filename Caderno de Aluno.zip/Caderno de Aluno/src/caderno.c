#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include "../Lib/lib.h"


extern Flashcard lista[10];
extern arvore T;


int menu, menulembrete, menuflashcard, menuquiz, media, i = 0, numero = 0, indice = 0, indiceUtilitario;
extern char pesquisa[50];



extern Materia nomeM[10];



int main()
{
    int op = -1;
    char texto[200] = {0};
    struct Registro *elemento;
    Lista lista2;
    cria(&lista2);

    printf("\tBem-vindo(a)!\n\n ");
    do
    {
        printf("Escolha uma opcao:\n\n 1- Lembretes\n 2- FlashCards \n 3- Quiz \n 0- Sair\n");
        printf("\nDigite aqui: ");
        scanf("%d", &menu);
        getchar();

        switch(menu)
        {
        case 1: //Menu do lembtrete, onde o aluno pode deixar anotações importantes
            printf("\n\n______ Lembretes ______\n\n");

            printf ("\nDigite o que deseja (1 para ver,  2 para adicionar, 0 pra voltar): ");
            scanf ("%d", &menulembrete);
            getchar();

            while(menulembrete == 1 || 2)
            {
                if(menulembrete == 1)
                {
                    pulaLinha();
                    printf ("\n\n------------------------------------------ Mostrando lembretes ------------------------------------------\n");
                    imprime_lista(&lista2);
                    printf("\n=====================================================================\n\n");
                    printf ("1 para ver,  2 para adicionar, 0 pra voltar: ");
                    scanf ("%d", &menulembrete);
                    getchar();
                }

                if(menulembrete == 2)
                {
                    pulaLinha();
                    printf ("\n++++++++++++ Adicione o lembrete ++++++++++++\n\n");
                    le(texto);
                    insere(&lista2, texto);
                    getchar();
                    memset(texto, '\0', 200);
                    printf("\n=====================================================================\n\n");
                    printf ("1 para ver,  2 para adicionar, 0 pra voltar: ");
                    scanf ("%d", &menulembrete);
                    getchar();
                }

                if(menulembrete == 0)
                {
                    pulaLinha();
                    printf("\nMenu do Caderno!\n\n");
                    printf("\n###########################\n\n");
                    printf("2022. By: Gabriel Dina Sales, Gabriel Sasuke Yamauchi de Souza, Luiz Felipe Terra da Silva e Vittoria Dutra Teixeira Pirro.");
                    break;
                }


                if(menulembrete > 2)
                {
                    printf("\n\nOpcao invalida para esse menu. Retornando...");
                    printf("\n\n------------------------------------------\n\n");
                    break;
                }
                printf("\n\n----------------------------------------------------------------------------------------------------------------\n\n");
            }
            break;

        case 2: //Menu do FlashCard, onde o aluno pode armazenar as notas totais de cada mat�ria, por exemplo: Modelagem 3D - 90; AOC - 70
            printf("\n\n______ FlashCards ______\n\n");

            printf ("Digite o que deseja (1 mostrar materias,  2 inserir materia, 3 pesquisar materia ou 0 para sair): ");
            scanf ("%d", &menuflashcard);
            getchar();

            while(menuflashcard == 1 || 2 || 3) //Loop para que continue sendo executado enquanto o usuario n�o digitar 0 para voltar ao menu principal
            {
                if(menuflashcard == 1)
                {
                    pulaLinha();
                    printf ("\n\n------------------------------------------ Exibindo listas de materias ------------------------------------------\n");
                    for(i=0; i < indice; i++)
                        printf("%2d-\t%s\t%s\n", i+1, lista[i].materia, lista[i].nota);
                    printf("\n=====================================================================\n\n");
                    printf ("\n1 mostrar materias,  2 inserir materia, 3 pesquisar materia ou 0 para sair: ");
                    scanf ("%d", &menuflashcard);
                    getchar();
                }

                if(menuflashcard == 2)
                {
                    pulaLinha();
                    if(indice < 10)
                    {
                        printf("\n++++++++++++ Inserindo materia ++++++++++++\n\n");
                        insereFlash();
                    }
                    else
                        printf("\n\nMaximo de materias!\n");
                        printf ("\n1 mostrar materias,  2 inserir materia, 3 pesquisar materia ou 0 para sair: ");
                        scanf ("%d", &menuflashcard);
                        getchar();
                }

                if(menuflashcard == 3)
                {
                    pulaLinha();
                    printf("\n************** Pesquisando materia **************\n");
                    pesquisaMateriaFlash();
                    printf("\n=====================================================================\n\n");
                    printf ("\n1 mostrar materias,  2 inserir materia, 3 pesquisar materia ou 0 para sair: ");
                    scanf ("%d", &menuflashcard);
                    getchar();
                }

                if(menuflashcard == 0)
                {
                    pulaLinha();
                    printf("\nMenu do Caderno!\n\n");
                    printf("\n###########################\n\n");
                    printf("2022. By: Gabriel Dina Sales, Gabriel Sasuke Yamauchi de Souza, Luiz Felipe Terra da Silva e Vittoria Dutra Teixeira Pirro.");
                    break;
                }

                if(menuflashcard > 4)
                {
                    printf("\n\nOpcao invalida para esse menu. Retornando...");
                    printf("\n\n------------------------------------------\n\n");
                    break;
                }
                printf("\n\n----------------------------------------------------------------------------------------------------------------\n\n");
            }
            break;

        case 3: //Menu do quiz, onde o aluno pode adicionar uma materia e se auto-avaliar/ registrar desempenho
            printf("\n\n______ Quiz ______\n\n");

            printf ("Digite o que deseja (1 se avaliar, 0 para voltar): ");
            scanf ("%d", &menuquiz);
            getchar();

            while(menuquiz != 0) //Loop para que continue sendo executado enquanto o usuario n�o digitar 0 para voltar ao menu principal
            {
                if(menuquiz == 1)
                {
                    pulaLinha();
                    printf ("!!!!!!!!!!!!!! Comecando o quiz !!!!!!!!!!!!!!\n\n");
                    funcQuiz();
                    printf("\n=====================================================================\n\n");
                    printf ("\n1 se avaliar novamente, 2 ver materias adicionadas, 0 pra voltar: ");
                    scanf ("%d", &menuquiz);
                    getchar();
                }

                if(menuquiz == 2)
                {
                    printf("\n\n------------------------------------------ Mostrando materias ------------------------------------------\n");
                    printf("Ordem alfabetica (A-Z):\n\n");
                    inOrdem(T);
                    printf("\n=====================================================================\n\n");
                    break;
                }

                if(menuquiz == 0)
                {
                    printf ("\n\nVoltando a tela inicial...\n\n");
                    printf("\n\n------------------------------------------\n\n");
                    break;
                }

                if(menuquiz > 2)
                {
                    printf("\n\nOpcao invalida para esse menu. Retornando...");
                    printf("\n\n------------------------------------------\n\n");
                    break;
                }
                printf("\n\n----------------------------------------------------------------------------------------------------------------\n\n");
            }
            break;

        case 0:
            printf("\nAgradecemos por usar o Caderno de Aluno! Encerrando...\n\n");
            printf("\n###########################\n\n");
            printf("By: \n | Gabriel Dina Sales | \n | Gabriel Sasuke Yamauchi de Souza | \n | Luiz Felipe Terra da Silva | \n | Vittoria Dutra Teixeira Pirro |\n\n");
            printf("\t\t\t||  ||\n\t\t\t\\\\()//\n                       //(__)\\\\\n                       ||    ||\n \t\t       Dez. 2022\n\n");
            break;

        default:
            printf("\n\nNumero invalido, voltando ao menu inicial...\n\n\n\n");
            printf("###########################\n\n");
        }
    }
    while (menu != 0);
}


