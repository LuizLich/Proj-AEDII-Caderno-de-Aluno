typedef struct //Struct para armazenar os dados do flashcard
{
    char materia[50];
    char nota[15];
} Flashcard; //Define o nome do novo tipo criado

struct no   //Struct para percorrer a arvore
{
    struct no *esq;
    char dado[20];
    struct no *dir;
};
typedef struct no *arvore;


typedef struct //Struct para armazenar os dados do quiz
{
    char nome[50]; //Nome da materia
    int pontuacao, perguntas;
} Materia; //Define o nome do novo tipo criado


struct Registro //Struct para os lembretes
{
    char texto[200];
    struct Registro *prox;
};

typedef struct //Typedef referente ao Registro de lembretes
{
    struct Registro *inicio;
    struct Registro *final;

} Lista;

void insereFlash();                     //Fun��o que recebe os dados da materia a nota da mesma
void pesquisaMateriaFlash();            //Fun��o para receber o nome da mat�ria que o usu�rio deseja pesquisar
void sortFlashcard(int tam);            //InsertionSort para ordena��o dos dados no flashcard
int pesquisaBinaria(char*, int, int);   //Fun��o que faz a busca do dado desejado pelo usu�rio
void funcQuiz();                        //Fun��o para o sub-menu do Quiz para que o usu�rio digite os dados
void insertNode(arvore *t, char d[20]); //Inserindo o no t para preparar a ordena��o
void inOrdem(arvore t);                 //Mostrar as materias inseridas no quiz em ordem alfabetica
void imprime_lista(Lista*lista2);       //Imprimir os lembretes
void le(char *texto);                   //Receber a variável texto para incluir na lista
int insere(Lista *lista2,char *texto);  //Incluir na lista o que texto recebeu
void cria(Lista *lista2);               //Criar lista para lembretes
void pulaLinha();                       //Função com vários \n apenas para melhor leitura e organização no terminal de saída


